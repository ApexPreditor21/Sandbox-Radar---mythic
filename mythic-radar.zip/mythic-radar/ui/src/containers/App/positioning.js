export default {
    1: {
        top: null,
        bottom: 20,
        right: 20,
        left: null,
    },
    2: {
        top: 0,
        bottom: 0,
        right: 20,
        left: null,
    },
    3: {
        top: 20,
        bottom: null,
        right: 20,
        left: null,
    },
    4: {
        top: 20,
        bottom: null,
        right: 0,
        left: 0,
    },
    5: {
        top: 20,
        bottom: null,
        right: null,
        left: 20,
    },
    6: {
        top: 0,
        bottom: 0,
        right: null,
        left: 20,
    },
    7: {
        top: null,
        bottom: '25%',
        right: null,
        left: 20,
    },
};